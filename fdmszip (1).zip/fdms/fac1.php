<!DOCTYPE html>
<html lang="en">
<head>
    <title>Home - FACULTY MANAGEMENT SYSTEM</title>
    <link rel="stylesheet" href="s.css">
</head>
<body>

    <div class="main">
        <div class="navbar">
        <div class="icon">
    <h2 class="logo">WELCOME <?php echo isset($_SESSION['username']) ? $_SESSION['username'] : ''; ?></h2>
</div>


            <div class="menu">
                <ul>
                    <li class="active"><a href="fac.php">Home</a></li>
                    <li><a href="depart.php">Departments</a></li>
                    <li><a href="login.php">Faculty Login</a></li>
                    <li><a href="#">Admin Login</a></li>

                </ul>
            </div>

        </div> 
        <div class="search">
            <input class="srch" type="search" name="" placeholder="Type To text">
            <a href="#"> <button class="btn">Search</button></a>
        </div>

        <div class="content">
            <h1>Welcome to Faculty Management System</h1>
            <p class="par">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin lacinia neque non felis cursus
                rutrum. Sed vel sem vitae orci luctus tempor. Donec id mauris eget magna condimentum sollicitudin.
                Curabitur sed elit in turpis convallis finibus.</p>
            <p class="par">In hac habitasse platea dictumst. Nulla facilisi. Integer efficitur, ipsum nec
                consectetur sollicitudin, enim purus commodo metus, non varius ipsum diam eget nisl. Cras congue
                justo a arcu fermentum, ac molestie ex iaculis. Duis mattis auctor justo, at posuere elit
                consectetur non. Cras tempus felis vel dolor varius tempus.</p>
            <button class="cn"><a href="#">Click here</a></button>
        </div>
    </div>

    <script src="https://unpkg.com/ionicons@5.4.0/dist/ionicons.js"></script>
</body>
</html>
